# MediPulse - Advanced Healthcare Chatbot

## Overview
MediPulse (formerly Lifeline) is a comprehensive AI-powered healthcare companion designed to help users monitor, manage, and improve their health and wellness. With over 65 features spanning health tracking, wellness tools, and medical resources, MediPulse provides a complete health management solution in a user-friendly interface with a perfect modern UI design.

## Key Features

### Core AI Capabilities
- AI-powered health Q&A with the Gemini API
- Natural language processing for health queries
- Personalized health recommendations
- Medical information with proper disclaimers

### Health Tracking & Monitoring
1. **Personalized Health Dashboard** - Overview of health metrics, goals, and progress
2. **Vital Signs Tracker** - Log and monitor blood pressure, heart rate, temperature, etc.
3. **Sleep Quality Analysis** - Track sleep patterns with improvement recommendations
4. **Mood & Mental Health Tracker** - Daily mood logging with trends and support resources
5. **Chronic Condition Management** - Specialized tracking for diabetes, hypertension, etc.
6. **Pain Journal** - Track location, intensity, triggers, and effective remedies
7. **Medication Reminder & Tracker** - Schedule, dosage alerts, and adherence tracking
8. **Period & Fertility Tracker** - Menstrual cycle tracking with predictions and symptom logging
9. **Family Health History Tool** - Record and analyze hereditary health risks

### Nutrition & Diet
10. **BMI Calculator** - Calculate BMI with health recommendations
11. **Water Intake Tracker** - Personalized hydration goals and reminders
12. **Meal Planner & Recipe Suggestions** - Personalized based on dietary needs
13. **Nutrition Calculator** - Analyze nutritional content of meals and daily intake
14. **Food Diary** - Log meals with analysis of nutritional patterns
15. **Dietary Restriction Guide** - Specialized advice for allergies and preferences
16. **Portion Size Visualizer** - Visual guides for appropriate portion sizes
17. **Intermittent Fasting Timer** - Track fasting periods with guidance

### Fitness & Exercise
18. **Workout Generator** - Customized exercise routines based on goals and equipment
19. **Exercise Library** - Video demonstrations of proper exercise techniques
20. **Step Counter Integration** - Connect with device sensors to track daily steps
21. **Calorie Burn Calculator** - Estimate calories burned during various activities
22. **Fitness Goal Setting & Tracking** - Set and monitor progress toward fitness milestones
23. **Stretching & Flexibility Guide** - Routines for improving flexibility
24. **Posture Analysis & Correction** - Tips and exercises for better posture
25. **Recovery & Rest Day Recommendations** - Guidance on optimal recovery

### Mental Wellness
26. **Stress Assessment & Management** - Evaluate stress levels and provide coping strategies
27. **Guided Breathing Exercises** - Various breathing techniques for different situations
28. **Advanced Meditation Library** - Multiple meditation styles with guided sessions
29. **Cognitive Behavioral Therapy Tools** - Basic CBT exercises for managing thoughts
30. **Gratitude Journal** - Daily prompts for practicing gratitude
31. **Positive Affirmations** - Customized affirmations based on user needs
32. **Sleep Stories & Sounds** - Calming narratives and ambient sounds for better sleep
33. **Mental Health Resource Locator** - Find local mental health services

### Medical Information & Support
34. **Symptom Analyzer Pro** - Advanced symptom assessment with AI-driven insights
35. **Medical Term Dictionary** - Explain complex medical terminology in simple language
36. **Drug Interaction Checker** - Identify potential interactions between medications
37. **Vaccination Schedule** - Personalized immunization tracking and reminders
38. **Telehealth Appointment Finder** - Help locate virtual healthcare providers
39. **Medical Document Storage** - Secure storage for health records and test results
40. **Emergency Contact Manager** - Store and quickly access emergency contacts
41. **Hospital & Clinic Locator** - Find nearby healthcare facilities with ratings
42. **First Aid Instructions** - Step-by-step guides for common emergencies
43. **Daily Health Tips** - Curated health and wellness tips

### Lifestyle & Prevention
44. **Habit Builder** - Create and track healthy habits with streak monitoring
45. **Ergonomic Workspace Assessment** - Tips for setting up a health-conscious workspace
46. **Screen Time Manager** - Track and limit digital device usage
47. **Sun Exposure & UV Index Alerts** - Skin protection recommendations based on location
48. **Allergy & Pollen Forecasts** - Local allergen levels with personalized alerts
49. **Air Quality Monitor** - Local air quality information with health recommendations
50. **Travel Health Planner** - Vaccination and health recommendations for destinations
51. **Seasonal Health Tips** - Advice tailored to current season and local conditions

### Social & Community
52. **Health Challenge Creator** - Create and participate in health improvement challenges
53. **Anonymous Support Groups** - Connect with others managing similar health conditions
54. **Health Goal Sharing** - Share achievements with trusted contacts for accountability
55. **Caregiver Resources** - Tools and support for those caring for others
56. **Health News Curator** - Personalized feed of relevant health news and research

### Advanced Technology Features
57. **Voice-Controlled Interface** - Hands-free operation of the chatbot
58. **Wearable Device Integration** - Connect with fitness trackers and smartwatches
59. **Health Data Export & Import** - Compatibility with other health platforms
60. **Offline Mode** - Access core features without internet connection
61. **Chat History Storage** - Save conversations for future reference
62. **Dark Mode & Accessibility Options** - Visual comfort and accessibility features
63. **Multiple Language Support** - Interface in various languages
64. **Customizable Dashboard** - Personalize your health information display
65. **Data Visualization** - Clear charts and graphs of your health metrics

## UI Design Features
- Modern, clean interface with gradient blue header
- Custom robot healthcare icon
- Responsive design for all device sizes
- Smooth animations and transitions
- Dark mode support
- Accessibility features including font size adjustment
- Intuitive navigation with dropdown menu
- Organized tools panel with categorized features
- Voice control button for hands-free operation
- Modal dialogs for focused tool interactions
- Consistent color scheme and typography

## Technical Information

### API Integration
MediPulse uses the Google Gemini API for AI-powered health conversations. The current implementation uses the `gemini-2.0-flash` model through the v1 API endpoint.

### Browser Compatibility
- Chrome (recommended)
- Firefox
- Safari
- Edge
- Opera

### Mobile Responsiveness
MediPulse is fully responsive and works on smartphones and tablets.

## How to Run the Project

### Method 1: Using VS Code with Live Server
1. Open VS Code
2. Click on "File" > "Open Folder" and select the MediPulse folder
3. Install the "Live Server" extension:
   - Click on the Extensions icon in the sidebar (or press Ctrl+Shift+X)
   - Search for "Live Server" by Ritwick Dey
   - Click "Install"
4. Once installed, right-click on index.html in the Explorer panel
5. Select "Open with Live Server"
6. The application will automatically open in your default browser

### Method 2: Direct Browser Opening
1. Navigate to the MediPulse folder in your file explorer
2. Double-click on index.html to open it in your default browser
3. For a specific browser (like Chrome):
   - Right-click on index.html
   - Select "Open with" > "Google Chrome" (or your preferred browser)

## Using MediPulse

### Basic Usage
- Type health questions or commands in the chat input
- Click the menu button (⋮) to access additional options
- Toggle the tools panel to see all available health tools

### Voice Commands
Click the microphone button to use voice input for hands-free operation.

### Tool Access
Access tools in three ways:
1. Through the menu button in the top-right corner
2. Via the tools panel (toggle through menu)
3. By typing commands like "calculate bmi", "water reminder", etc.

### Chat Commands
- "dashboard" - Open health dashboard
- "calculate bmi" - Open BMI calculator
- "water reminder" - Open water intake tracker
- "health tip" - Get a random health tip
- "first aid" - Access first aid instructions
- "symptom check" - Open symptom checker
- "meditate" - Open meditation guide
- "medication" - Manage medications
- "vitals" - Track vital signs
- "sleep" - Track sleep patterns
- "mood" - Track mood and emotions
- "nutrition" - Access nutrition tools
- "exercise" - Access exercise tools
- "clear history" - Clear chat history
- "help" - Show information about MediPulse

## Privacy & Security
- All data is stored locally in your browser
- No personal health information is transmitted to external servers
- The Gemini API only receives your chat messages for processing responses

## Disclaimer
MediPulse is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.

## Credits
- Developed by the MediPulse Health Technologies team
- Powered by Google's Gemini API
- Icons by Font Awesome
- Fonts by Google Fonts

© 2025 MediPulse Health Technologies
